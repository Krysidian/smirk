import bpy
from pathlib import Path


ASSET_FILENAME = "smirk_assets.blend"



def resolve_asset_path(filename: str = ASSET_FILENAME) -> Path:
    folder_root = Path(__file__).resolve().parent
    return folder_root / filename


def get_asset_nodetree(tree_name: str, asset_filename: str = ASSET_FILENAME) -> bpy.types.NodeTree:
    
    # Check if the NodeTree already exists
    existing_nodetree = bpy.data.node_groups.get(tree_name)
    if existing_nodetree is not None:
        return existing_nodetree
    
    asset_path = resolve_asset_path(asset_filename)
    if not asset_path.exists():
        raise FileNotFoundError(f"Library file not found: {asset_path}")
    
    asset_path_str = str(asset_path)
    with bpy.data.libraries.load(asset_path_str, link=False) as (data_from, data_to):
        if tree_name not in data_from.node_groups:
            raise ValueError(
                f"Node tree '{tree_name}' not found in '{asset_filename}'.\n"
                f"Available: {list(data_from.node_groups)}"
            )
        data_to.node_groups = [tree_name]

    appended_nodetree = bpy.data.node_groups.get(tree_name)
    return appended_nodetree

# add no proxy prefix for modifier names to exclude them from copying

def _add_simple_driver(target_id, target_path, src_id, src_path, index=None):
    """Add a driver on target_id.target_path that reads src_id.src_path.

    If `index` is provided, it will call driver_add(data_path, index). This
    covers array properties like location/scale/rotation components.
    """
    try:
        # driver_add accepts either (data_path) or (data_path, index)
        if index is None:
            fcurve = target_id.driver_add(target_path)
        else:
            fcurve = target_id.driver_add(target_path, index)
    except Exception:
        return False

    # Normalize FCurve/list return and retrieve its driver (use helper)
    driver = _get_driver_from_fcurve(fcurve)
    if driver is None:
        return False

    try:
        # Clear any existing variables and set a single SIMPLE_PROP variable
        for v in list(driver.variables):
            driver.variables.remove(v)

        var = driver.variables.new()
        var.name = 'var'
        var.type = 'SINGLE_PROP'
        targ = var.targets[0]
        targ.id = src_id
        targ.data_path = src_path
        driver.expression = 'var'
        return True
    except Exception:
        return False

def _get_driver_from_fcurve(fcurve):
    """Normalize possible list/FCurve return from driver_add and return its driver or None."""
    
    if isinstance(fcurve, (list, tuple)):
        if len(fcurve) == 0:
            return None
        fcurve = fcurve[0]
    return getattr(fcurve, 'driver', None)

def _switch_properties_to_modifier_tab() -> bool:
    """Set any Properties editor to the Modifier context. Returns True if changed."""
    try:
        # quick path: if current space is a Properties editor
        space = getattr(bpy.context, "space_data", None)
        if space is not None and getattr(space, "type", "") == "PROPERTIES":
            space.context = "MODIFIER"
            return True
    except Exception:
        pass

    # fallback: search all windows/screens for a Properties area
    for window in bpy.context.window_manager.windows:
        try:
            for area in window.screen.areas:
                if area.type == "PROPERTIES":
                    try:
                        # preferred: use active space
                        area.spaces.active.context = "MODIFIER"
                        return True
                    except Exception:
                        # fallback: iterate spaces in area
                        for space in area.spaces:
                            if getattr(space, "type", "") == "PROPERTIES":
                                space.context = "MODIFIER"
                                return True
        except Exception:
            continue
    return False

class SMIRK_OT_setup_proxy_mesh(bpy.types.Operator):
    bl_idname = "smirk.setup_proxy_mesh"
    bl_label = "Setup Proxy"
    bl_description = "Create a linked duplicate of the selected Object that will be used as a target for certain modifiers" 
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):  # type: ignore
        print(get_asset_nodetree("Smirk Boolean"))
        orig = context.active_object
        if orig is None:
            self.report({'ERROR'}, "No active object")
            return {'CANCELLED'}
        
        # Prevent running this operator on a proxy object (avoid nesting proxies)
        if orig.name.startswith('PROXY-'):
            self.report({'ERROR'}, "Operator cannot run on a PROXY Object")
            return {'CANCELLED'}
        
        # Determine proxy name and whether a proxy already exists
        base_name = f"PROXY-{orig.name}"
        existing_proxy = None

        for obj in bpy.data.objects:
            if obj.name == base_name or obj.name.startswith(base_name + '.'):
                existing_proxy = obj
                break

        if existing_proxy is not None:
            proxy = existing_proxy
            proxy_exists = True
        else:
            # Create a linked duplicate (object copy keeps data linked by default)
            proxy = orig.copy()
            # Keep linked mesh data (do not .copy() data)1
            proxy.data = orig.data

            # Ensure unique proxy name
            name = base_name
            i = 1
            while name in bpy.data.objects:
                name = f"{base_name}.{i:03d}"
                i += 1
            proxy.name = name
            proxy_exists = False

        
        # Link proxy to the same collections as the original (or to context.collection as fallback)
        linked_any = False
        try:
            for coll in orig.users_collection:
                coll.objects.link(proxy)
                linked_any = True
        except Exception:
            pass
        if not linked_any:
            # context.collection may be None in some contexts; fall back to scene.collection
            target_coll = getattr(context, 'collection', None)
            if target_coll is None:
                target_coll = getattr(context.scene, 'collection', None)

            if target_coll is not None:
                try:
                    target_coll.objects.link(proxy)
                except Exception:
                    # as last resort, link to the master collection if available
                    try:
                        bpy.context.scene.collection.objects.link(proxy)
                    except Exception:
                        pass

        # Drivers for transforms: location, scale, rotation (handle Euler/Quaternion/Axis-Angle)
        # Only create transform drivers if we are making a new proxy
        if not proxy_exists:
            # Location
            for i in range(3):
                _add_simple_driver(proxy, 'location', orig, f'location[{i}]', index=i)

            # Scale
            for i in range(3):
                _add_simple_driver(proxy, 'scale', orig, f'scale[{i}]', index=i)

            # Rotation Quaternion
            if orig.rotation_mode == 'QUATERNION':
                for i in range(4):
                    _add_simple_driver(proxy, 'rotation_quaternion', orig, f'rotation_quaternion[{i}]', index=i)
            # Rotation Axis Angle
            elif orig.rotation_mode == 'AXIS_ANGLE':
                for i in range(4):
                    _add_simple_driver(proxy, 'rotation_axis_angle', orig, f'rotation_axis_angle[{i}]', index=i)
            # Rotation Euler
            else:
                for i in range(3):
                    _add_simple_driver(proxy, 'rotation_euler', orig, f'rotation_euler[{i}]', index=i)

        # Get list of modifiers on the original object
        orig_mod_names = [m.name for m in orig.modifiers]
        
        # Remove modifiers on proxy that are not present on original
        for m in list(proxy.modifiers):
            if m.name not in orig_mod_names:
                try:
                    proxy.modifiers.remove(m)
                except Exception:
                    pass

        # Ensure proxy has modifiers from original (create missing ones)
        for mod in orig.modifiers:

            #copy over Modifiers from orig
            if mod.name not in proxy.modifiers.keys():
                try:
                    new_mod = proxy.modifiers.new(name=mod.name, type=mod.type)
                    # If this is a node group based modifier, try to copy the node_group reference
                    if mod.type == 'NODES' and getattr(mod, 'node_group', None) is not None:
                        try:
                            new_mod.node_group = mod.node_group
                        except Exception:
                            pass
                except Exception:
                    # unable to create new modifier; continue and still attempt drivers
                    pass

            for prop in mod.bl_rna.properties:
                if getattr(prop, 'is_readonly', False):
                    continue

                # Skip internal/rna properties
                ident = prop.identifier
                if ident in {'rna_type', 'name', 'type'}:
                    continue
                prop_type = getattr(prop, 'type', None)
                if prop_type not in {'BOOLEAN', 'INT', 'FLOAT', 'ENUM'}:
                    continue

                src_path = f'modifiers["{mod.name}"].{ident}'
                target_path = src_path

                # Use helper which wraps driver_add and variable setup
                success = False
                try:
                    # Try with full path (no index)
                    success = _add_simple_driver(proxy, target_path, orig, src_path, index=None)
                except Exception:
                    success = False

                # Fallback: try to add with explicit path string if needed by API
                if not success:
                    try:
                        success = _add_simple_driver(proxy, f'modifiers["{mod.name}"].{ident}', orig, src_path, index= None)
                    except Exception:
                        success = False

            # Remove Geometry Node modifiers using node group "Smirk Boolean"
            for m in list(proxy.modifiers):
                try:
                    if m.type == 'NODES' and getattr(m, 'node_group', None) is not None:
                        if getattr(m.node_group, 'name', '') == "Smirk Boolean":
                            proxy.modifiers.remove(m)
                except Exception:
                    continue

        # Make proxy visible/active
        try:
            # Deselect all, select orig and make active
            for o in context.selected_objects:
                o.select_set(False)
        except Exception:
            pass
        try:
            orig.select_set(True)
            context.view_layer.objects.active = orig
        except Exception:
            pass

        self.report({'INFO'}, f"Proxy '{proxy.name}' created/updated for '{orig.name}'")
        return {'FINISHED'}

class SMIRK_OT_add_modifier(bpy.types.Operator):
    bl_idname = "smirk.add_modifier"
    bl_label = "Add Smirk Modifier"
    bl_description = "Create a linked duplicate of the selected Object that will be used as a target for certain modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        smirk_mod = context.active_object.modifiers.new('Smirk Boolean', type='NODES')
        smirk_mod.node_group = get_asset_nodetree("Smirk Boolean")
        smirk_mod.show_group_selector = False

        _switch_properties_to_modifier_tab()


        return {"FINISHED"}

class SMIRK_OT_switch_tab(bpy.types.Operator):
    bl_idname = "smirk.to_tab"
    bl_label = "Switch Properties to a specific Tab"
    bl_description = "Switches the current Properties Panel to a specific tab"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        _switch_properties_to_modifier_tab()

        return {"FINISHED"}


_classes = (
    SMIRK_OT_setup_proxy_mesh,
    SMIRK_OT_add_modifier,
    SMIRK_OT_switch_tab,
)


register, unregister = bpy.utils.register_classes_factory(_classes)
    